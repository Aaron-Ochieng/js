# Clonernews

A simple UI to display Hacker News posts using the Hacker News API. This project fetches and displays the latest top stories from Hacker News and updates the list of posts every 5 seconds.

## Features

- **Display Top Stories**: Shows the top stories from Hacker News.
- **Live Updates**: Refreshes the list of posts every 5 seconds to keep content up-to-date.
- **Pagination**: Loads a fixed number of posts per request to improve performance and usability.
- **Basic Styling**: Provides a clean and readable layout using basic CSS.

## Technologies Used

- **HTML**: For the structure of the page.
- **CSS**: For styling the UI.
- **JavaScript**: For fetching data from the Hacker News API and updating the UI.

## Getting Started

### Prerequisites

No prerequisites are required to run this project. You only need a web browser.

### Installation

1. **Clone the Repository**
   
   ```bash
   git clone https://learn.zone01kisumu.ke/git/jowala/clonernews.git
   ```

2. Navigate to the Project Directory
   
   ```bash
   cd clonernews
   ```
   
     cd clonernews

3. Open the HTML File
   
    Open index.html in your web browser to view the application.

### Display
- Output
![](./assets/clonernews.png)

## How It Works

    Fetch Top Stories: The application fetches the IDs of the top stories from the Hacker News API.
    Display Posts: It then fetches detailed information about these stories and displays them on the page.
    Live Data Updates: The app checks for new data every 5 seconds and updates the displayed posts accordingly.

## Code Overview

    index.html: The HTML structure of the application.
    script.js: The JavaScript file that handles fetching data from the Hacker News API, updating the UI, and implementing live updates.
    styles.css: The CSS file (included within <style> tags in index.html) for styling the UI.

## API Documentation

The project uses the Hacker News API to fetch data. Key endpoints used include:

    https://hacker-news.firebaseio.com/v0/topstories.json - Gets the list of top story IDs.
    https://hacker-news.firebaseio.com/v0/item/<id>.json - Gets detailed information about a specific story/item.
    https://hacker-news.firebaseio.com/v0/maxitem.json - Gets the ID of the most recent item.

# Tests

This project uses [Cypress](https://www.cypress.io/) for end-to-end testing. Cypress provides a fast, easy, and reliable testing environment for your web applications. To run the tests, ensure you have Cypress installed and follow the steps below.

### Prerequisites

Make sure all dependencies are installed:

```bash
npm install
```

Ensure that you have vscode installed and live-server extension installed.

Launch `index.html` using the `live server` which will run on port `5500` by default which was used for testing the application.

### Running Cypress Tests

1. Open Cypress Test Runner:
   
   ```bash
   npm run cy:open
   ```

Cypress GUI will open then select browser you prefer to use then select`e2e` testing.

Run the already written tests . This will execute the test cases in the browser intance which the cypress launched.

### Writing New Tests

To write new Cypress tests, add your test files in the `cypress/integration/` folder. Each test should follow the standard structure of a Cypress test:

```bash
describe('Feature name', () => {
  it('should do something', () => {
    // test implementation
    cy.visit('http://localhost:3000');
    cy.get('.element-selector').click();
    // additional test commands
  });
});
```

For more information on writing Cypress tests, refer to the Cypress documentation.

### Test Reports

By default, running `npx cypress run` will generate test reports that you can review to ensure everything is functioning as expected. For continuous integration setups, configure Cypress to generate more detailed reports using Cypress reporters.

## Contributing

Feel free to submit issues or pull requests if you have suggestions for improvements or new features.

## License

The project is licensed under the MIT License - see the LICENSE file for details.

## Authors

- [@steoiro](https://learn.zone01kisumu.ke/git/steoiro)
- [@aaochieng](https://learn.zone01kisumu.ke/git/aaochieng)
- [@jowala](https://learn.zone01kisumu.ke/git/jowala)
