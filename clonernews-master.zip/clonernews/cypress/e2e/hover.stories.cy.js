describe('Scroll through the page', () => {
    beforeEach(() => {
        cy.visit('http://localhost:5500')
    }),
        it('', () => {
            cy.get('.dropdown')
                .trigger('');

            cy.get('.dropdown-content')
                .should('be.visible'); // Check that the dropdown is visible

            // Verify the dropdown contains the expected number of links
            cy.get('.dropdown-content a')
                .should('have.length', 5);
        })


});
