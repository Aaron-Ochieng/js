describe('Test polls page', () => {
    beforeEach(() => {
        cy.visit('http://localhost:5500')

    })
    it('click polls button', () => {
        cy.get('a[data-story-type="poll"]')
            .click();
    })
    it('must show 20 loaded the polls', () => {
        const polls_container = '#content'
        const polls = 'article.post';
        const load_more_btn = '#load-more';


        const get_displayed_post_count = () => {
            return cy.get(polls_container).find(polls).its('length');
        }

        get_displayed_post_count().should('equal', 20);

        cy.scrollTo('bottom')
        cy.get(load_more_btn).should('be.visible').and('not.be.disabled').click()
    })

})