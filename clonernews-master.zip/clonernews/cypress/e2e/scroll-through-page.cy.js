describe('Scroll through the page', () => {
    beforeEach(() => {
        cy.visit('http://localhost:5500')
    }),


        it('check the count of the articles loaded in the current page', () => {
            const articles_container = '#content'
            const articles = 'article.post';
            const load_more_btn = '#load-more';


            const get_displayed_post_count = () => {
                return cy.get(articles_container).find(articles).its('length');
            }

            get_displayed_post_count().should('equal', 20);

            cy.scrollTo('bottom')
            cy.get(load_more_btn).should('be.visible').and('not.be.disabled').click()
        }),

        it('Scroll to to and hover over story element', () => {
            cy.scrollTo('top');
            cy.get('.dropbtn')
                .trigger('mouseover');

            cy.get('a[data-story-type="job"]')
                .click();

        }),

        it('check the count of the jobs loaded in the current page', () => {
            const jobs_container = '#content'
            const articles = 'article.post';
            const load_more_btn = '#load-more';


            const get_displayed_post_count = () => {
                return cy.get(jobs_container).find(articles).its('length');
            }

            get_displayed_post_count().should('equal', 20);

            cy.scrollTo('bottom')
            cy.get(load_more_btn).should('be.visible').and('not.be.disabled').click()
        })
})