describe('template spec', () => {
  it('passes', () => {
    cy.visit('http://localhost:5500')
  })
})